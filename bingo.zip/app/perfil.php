<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class perfil extends Model
{
    //
}
