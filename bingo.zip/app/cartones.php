<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cartones extends Model
{
    protected $table = 'cartones';
	protected $guarded = ['id'];

	
}
