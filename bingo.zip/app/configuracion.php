<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class configuracion extends Model
{
    protected $table = 'configuracion';
	protected $guarded = ['id'];
}
