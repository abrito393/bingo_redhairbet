<script src="{!! asset('js/jquery-3.4.1.js') !!}" crossorigin="anonymous"></script>
