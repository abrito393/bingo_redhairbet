<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cartones</title>
	<link rel="stylesheet" href="">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<style>
	table, th, td {
	  border: 1px solid black;
	  border-collapse: collapse;
	}
	th, td {
	  padding: 0.7rem;
	  text-align: left;
	  font-size: 1.5rem;
	}

	caption {
		padding-top: .75rem;
		padding-bottom: .75rem; 
		color: #6c757d; 
		text-align: center; 
		caption-side: top; 
		border: 1px solid black;
	}


</style>
<body>
	<div class="container">
		<div class="row" align="center">
			<?php $x = 0;?>
			<?php $__currentLoopData = $cartones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carton): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-6">
					<table>
						<caption align="center">
							<div class="row">
								<div class="col-4">
									<img style="width: 3rem;" src="<?php echo asset('img/logo_red_compressed.jpg'); ?>"> 
								</div>
								<div class="col-4" align="left">
									CARTON #000<?php echo e($x); ?>

								</div>
							</div>
							
						</caption>
						<tr>
							<?php for($i = 0; $i <= 8; $i++): ?>
								
								<?php if($carton[$i] == 0): ?>
									<th align="center">
										<img src="<?php echo asset('img/iconfinder_hexagon-polygon-screw-block.png'); ?>" alt="">
									</th>
								<?php else: ?>
									<th><?php echo e($carton[$i]); ?></th>
								<?php endif; ?>
							<?php endfor; ?>
						</tr>

						<tr>
							<?php for($i = 9; $i <= 17; $i++): ?>
								<?php if($carton[$i] == 0): ?>
									<th align="center"><img src="<?php echo asset('img/iconfinder_hexagon-polygon-screw-block.png'); ?>" alt=""></th>
								<?php else: ?>
									<th align="center"><?php echo e($carton[$i]); ?></th>
								<?php endif; ?>
							<?php endfor; ?>
						</tr>

						<tr>
							<?php for($i = 18; $i <= 26; $i++): ?>
								<?php if($carton[$i] == 0): ?>
									<th align="center"><img src="<?php echo asset('img/iconfinder_hexagon-polygon-screw-block.png'); ?>" alt=""></th>
								<?php else: ?>
									<th align="center"><?php echo e($carton[$i]); ?></th>
								<?php endif; ?>
							<?php endfor; ?>
						</tr>
						<br>
					</table><br><br>
				</div>
				<?php $x++;?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</body>
</html>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script><?php /**PATH C:\xampp\htdocs\laravel\bingo\resources\views/cartones.blade.php ENDPATH**/ ?>