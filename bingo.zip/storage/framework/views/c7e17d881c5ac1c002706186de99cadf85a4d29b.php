<script src="<?php echo asset('js/jquery-3.4.1.js'); ?>" crossorigin="anonymous"></script>
<?php /**PATH C:\xampp\htdocs\laravel\bingo\resources\views/call_js.blade.php ENDPATH**/ ?>