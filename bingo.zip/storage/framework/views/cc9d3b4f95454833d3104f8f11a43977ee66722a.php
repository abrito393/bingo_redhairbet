<li>
    <a href="/">
        <i class="fa fa-home"></i>
        <span class="link-title menu_hide">Inicio</span>
    </a>
</li>
<li>
    <a href="<?php echo e(route('sorteolist.index')); ?>">
        <i class="fa fa-home"></i>
        <span class="link-title menu_hide">Sorteo</span>
    </a>
</li><?php /**PATH C:\xampp\htdocs\laravel\bingo\resources\views/template/nav_bar.blade.php ENDPATH**/ ?>