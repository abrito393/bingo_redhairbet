<?php $__env->startSection('name_seccion'); ?>
    Listado de Sorteos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contend'); ?>
<div class="outer">
    <div class="inner bg-container">
        <div class="inner bg-container">
    		<div class="col-lg-12">
        <!-- BEGIN SAMPLE TABLE PORTLET-->
        <div class="card m-t-35">
            <div class="card-header bg-white">
                <i class="fa fa-table"></i> Listado
            </div>
            <div class="col-lg-12" align="right"><br>
                <a href="" class="btn btn-primary btn-xs ">
                    <i class=""></i> Nuevo 
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive m-t-35">
                    <table class="table table-striped table-bordered table-advance table-hover">
                        <thead>
                        <tr>
                            <th>
                                <i class="fa fa-bookmark"></i> Nombre 
                            </th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td >
                                        <?php echo e($dat->nombre); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('sorteoedit.edit',$dat->id)); ?>" class="btn btn-success btn-xs purple">
                                            <i class="fa fa-eye"></i> Editar
                                        </a>
                                        <a href="<?php echo e(route('sorteodelete.delete',$dat->id)); ?>" class="btn btn-danger btn-xs purple">
                                            <i class="fa fa-trash"></i> Eliminar
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row col-lg-12">
                <?php echo e($data->appends(Request::except('page'))->render()); ?>

            </div>

        </div>
        <!-- END SAMPLE TABLE PORTLET-->
    		</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('codejs'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#admin_categoria').addClass("active");
            $('#ul_admin_categoria').addClass("show");
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\bingo\resources\views/admin/sorteo/index.blade.php ENDPATH**/ ?>