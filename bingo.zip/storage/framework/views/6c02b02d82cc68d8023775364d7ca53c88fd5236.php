<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>B I N G O</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="img/logo1.ico"/>
    <!-- global styles-->
    <link  rel="stylesheet" href="<?php echo asset('admin/css/components.css'); ?>"/>
    <link  rel="stylesheet" href="<?php echo asset('admin/css/custom.css'); ?>"/>
    <!--End of the global styles-->
    <!-- end of page level styles -->
    <link rel="stylesheet"  href="<?php echo asset('admin/css/pages/widgets.css'); ?>">
</head>
<style type="text/css" media="screen">
	.btn{
		font-weight: bold;

	}
    body{
      background-color: white; /* Green */
      background: url('<?php echo e(asset('img/bg.jpg')); ?>') no-repeat center center fixed; 
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }

    .card{
		border-style: solid;
		border-width: 0.2rem;
		border-color: #ff0000 #00ff00 #0000ff rgb(250,0,255);
		border-radius: 2rem;
		font-size: 30px;
    }

	.grid-container {
	  display: grid;
	  grid-gap: 10px;
	  padding: 10px;
	}

	.grid-item {
	  padding: 5px;
	  
	  text-align: center;
	} 

	/* Extra small devices (phones, 600px and down) */
	@media  only screen and (max-width: 600px) {
		.grid-container {
		  grid-template-columns: auto auto auto auto;
		}
	}

	/* Small devices (portrait tablets and large phones, 600px and up) */
	@media  only screen and (min-width: 600px) {
		.grid-container {
		  grid-template-columns: auto auto auto auto auto auto auto auto      ;
		}
	}

	/* Medium devices (landscape tablets, 768px and up) */
	@media  only screen and (min-width: 768px) {
		.grid-container {
		  grid-template-columns: auto auto auto auto auto auto auto auto auto auto;
		}
	}

	/* Large devices (laptops/desktops, 992px and up) */
	@media  only screen and (min-width: 992px) {
		.grid-container {
		  grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto auto auto auto;
		}
	}

	/* Extra large devices (large laptops and desktops, 1200px and up) */
	@media  only screen and (min-width: 1200px) {
		.grid-container {
		  grid-template-columns: auto auto auto auto auto auto auto auto auto auto auto auto auto auto;
		}
	}
</style>
<body>
	<div class="">
		<?php echo e(csrf_field()); ?>

		<h1 align="center">B I N G O - R E D H A I R B E T. C O M</h1>
		<!--
	    <div class="row" id="contenedor_numeros">
	    	<?php for($i = 1; $i < 90; $i++): ?>
				<div class="col-xs-3 col-sm-1 col-md-1 col-lg-1 col-xl-1 number_box" style="padding: 0.5rem;">
					<div id="<?php echo e($i); ?>"  class="card p-d-15 " style="background-color: #73ffb2;">
						<div>
							<h1 class="sales_number  text-center" id="orders_countup"><?php echo e($i); ?></h1>
						</div>
					</div>
				</div>
			<?php endfor; ?>
	    </div>	-->

		<div class="grid-container">
	    	<?php for($i = 1; $i < 90; $i++): ?>
				<div class="grid-item number_box" style="padding: 0.5rem;">
					<div id="<?php echo e($i); ?>"  class=" card " style="background-color: #73ffb2;">
						<div>
							<div style="font-size: 2rem;font-weight: bold" class="sales_number  text-center" id="orders_countup"><?php echo e($i); ?></div>
						</div>
					</div>
				</div>
			<?php endfor; ?>
		</div>
		<audio id="myAudio">
		  <source src="<?php echo e(asset('audio/numero_1.oga')); ?>" type="audio/ogg">
		</audio>

		<div class="container" align="center" style="padding: 0.5rem;">
		  <button type="button" id="play" class="btn btn-black">JUGAR</button>
		  <button type="button" id="stop" class="btn btn-danger">DETENER</button>
		  <button type="button" class="btn btn-success">CARGAR JUEGO</button>
		  <button type="button" class="btn btn-info">REINICIAR</button>
		  <button type="button" class="btn btn-warning">CANCELAR JUEGO</button>
		  <button type="button" id="sonido" class="btn btn-success">SONIDO</button>  
		</div>
	</div>

</body>
</html>

<?php echo $__env->make('call_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
$(document).ready(function(){
	var numeros = new Array();
	var sorteo = new Array();
	var VarGame ;
	var token = $( "input[name='_token']" ).val();
	var numero_generado;
	var numero_actual = '0';

	var x = document.getElementById("myAudio");

	$("#accion").click(function(){
	  var urlx = "<?php echo e(route('GenerateNumbers')); ?>";
	  /*
	  var datos = new Array();
	  datos.push({
	    'nombre' : $( "#nombre" ).val(),
	    'descripcion' : $( "#descripcion" ).val(),
	    'especie_id' : $( "#especie_id" ).val()
	  });
	  var data = JSON.parse(JSON.stringify(datos));*/
	  $.ajax({
	    url: urlx,
	    type: 'POST',
	    headers: {'X-CSRF-TOKEN': token},
	    datatype: 'json',
	    data:{
	    },
	    success:function( respuesta ){
	    }
	  });
	});	

	function playAudio() { 
	  x.play(); 
	} 
	$("#sonido").click(function(){
		playAudio()
	});

	$("#play").click(function(){
		//alert('Inicia el juego');
		PlayGame();
		GenerarNumero();
	});

	$("#stop").click(function(){
		StopGame();
		alert('Se detuvo el juego');
	});

	GenerarSorteo();
	function GenerarSorteo() {
		while(numeros.length < 90){
		    var r = Math.floor(Math.random()*90) + 1;
		    if(numeros.indexOf(r) === -1) numeros.push(r);
		}
	}

	function GenerarNumero() {
		if(sorteo.length < 90){
			$("#"+numero_actual).css("background-color", "#73ffb2");
	    	$("#"+numeros[0]).css("background-color", "#fff039");
	    	numero_actual = numeros[0];
	    	sorteo.push(numeros[0]);
			numeros.shift();
		}


	}


	function PlayGame() {
		VarGame = setInterval(GenerarNumero, 3000);
		console.log('Star Game');
	}

	function StopGame() {
		clearInterval(VarGame);
		console.log('Stop Game');
	}



})
</script>
<?php /**PATH C:\xampp\htdocs\laravel\bingo\resources\views/bingo.blade.php ENDPATH**/ ?>